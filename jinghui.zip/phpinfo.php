
<?php
phpinfo();
?>
