<?php
return array(
    'code'=> 'cod',
    'name' => '到货付款',
    'version' => '1.0',
    'author' => 'IT宇宙人',
    'desc' => '货到付款插件 ',
    'icon' => 'logo.jpg',    
	'scene' =>0,  // 使用场景 0 PC+手机 1 手机 2 PC
    'config' => array(
        array('name' => 'code_desc','label'=>'配送描述',           'type' => 'text',   'value' => ''),       
    ),    	
);