<?php
return [
     'hello_JHshop'  => 'application 你好 JHshop',
     'I_love_you_JHshop' => 'application 我爱你 JHshop',
     'where' => '在 application zh-cn',
];