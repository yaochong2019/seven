<?php
return [
     'hello_JHshop'  => 'application hello tpshop 11',
     'I_love_you_JHshop' => 'application I love you JHshop 22',
     'where' => 'in application en-us',    
];