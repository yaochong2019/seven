<?php
return [
     'hello_JHshop'  => 'mobile hello tpshop 11',
     'I_love_you_JHshop' => 'mobile I love you JHshop 22',
];