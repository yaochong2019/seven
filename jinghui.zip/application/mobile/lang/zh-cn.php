<?php
return [
     'hello_JHshop'  => 'mobile 你好 JHshop',
     'I_love_you_JHshop' => 'mobile 我爱你 JHshop',
];