<?php
return [
     'INdex_hello_JHshop'  => 'home 你好 JHshop',
     'INdex_hello_JHshop'  => 'home 你好 JHshop',
     'INdex_hello_JHshop'  => 'home 你好 JHshop',
     'INdex_hello_JHshop'  => 'home 你好 JHshop',
    
    
     'User_I_love_you_JHshop' => 'home 我爱你 JHshop',
    'User_I_love_you_JHshop' => 'home 我爱你 JHshop',
    
];