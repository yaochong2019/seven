<?php
namespace app\admin\model;
use think\Model;
class GoodsCategory extends Model {

  
}
