<?php
namespace app\admin\model;
use think\model;
class SpecGoodsPrice extends model {
    
}
