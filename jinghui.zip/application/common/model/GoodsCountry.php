<?php
namespace app\common\model;
use think\Model;

class GoodsCountry extends Model {


}